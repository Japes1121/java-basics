Application has been done for settlement of outing using the MVC pattern.

Kindly run the Executor class in the package(main.java.executor)