package main.java.executor;

import main.java.data.FileReader;

/**
 *
 */
public class Executor {
    public static void main(String[] args) {
        FileReader fileReader = new FileReader();
        fileReader.getDetailsFromFiles();
    }
}
