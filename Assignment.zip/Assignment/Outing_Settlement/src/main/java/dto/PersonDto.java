package main.java.dto;

/**
 *
 */
public class PersonDto {

    private String name;

    private long amountSpent;

    private long amountPaid;

    private long toGive;

    private long toReceive;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getAmountSpent() {
        return amountSpent;
    }

    public void setAmountSpent(long amountSpent) {
        this.amountSpent = amountSpent;
    }

    public long getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(long amountPaid) {
        this.amountPaid = amountPaid;
    }

    public long getToGive() {
        return toGive;
    }

    public void setToGive(long toGive) {
        this.toGive = toGive;
    }

    public long getToReceive() {
        return toReceive;
    }

    public void setToReceive(long toReceive) {
        this.toReceive = toReceive;
    }
}
