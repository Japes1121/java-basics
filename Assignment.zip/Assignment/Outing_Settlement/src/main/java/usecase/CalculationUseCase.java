package main.java.usecase;

import main.java.dto.PersonDto;
import main.java.result.ResultProcessor;

import java.util.List;

/**
 *
 */
public class CalculationUseCase {

    public void calculateDebtsDetails(List<PersonDto> personDtoList) {
        for(PersonDto personDto : personDtoList) {
            long toGive = personDto.getAmountSpent() - personDto.getAmountPaid();
            long toReceive = personDto.getAmountPaid() - personDto.getAmountSpent();
            personDto.setToGive(toGive);
            personDto.setToReceive(toReceive);
        }
        ResultProcessor resultProcessor = new ResultProcessor();
        resultProcessor.getResults(personDtoList);
    }

}
