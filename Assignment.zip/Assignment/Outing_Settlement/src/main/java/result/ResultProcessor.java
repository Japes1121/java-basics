package main.java.result;

import main.java.dto.PersonDto;

import java.util.List;

/**
 *
 */
public class ResultProcessor {

    public void getResults(List<PersonDto> personDtoList) {
        for(PersonDto personDto : personDtoList) {
            if(personDto.getToGive() > 0){
                System.out.println(personDto.getName() +" has to give " +personDto.getToGive());
            } else if (personDto.getToReceive() > 0) {
                System.out.println(personDto.getName() +" gets " +personDto.getToReceive());
            }
        }

    }
}
