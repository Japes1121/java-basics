package main.java.data;

import main.java.dto.PersonDto;
import main.java.usecase.CalculationUseCase;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 */
public class FileReader {

    public void getDetailsFromFiles() {
            List<String> stringList = null;
            try {
                ClassLoader classLoader = getClass().getClassLoader();
                stringList = Files.lines(Paths.get(classLoader.getResource("input.txt").toURI()))
                            .collect(Collectors.toList());
            } catch (Exception e) {
                e.printStackTrace();
            }
            List<PersonDto> personDtoList = new ArrayList<>();
            for (String s : stringList) {

                String newValue1 = replaceText(s);
                String[] splitStr = newValue1.trim().split("\\s+");

                final int count = splitStr.length - 3;
                for(int i =3; i < splitStr.length; i++) {
                    String name = splitStr[i];
                    long amount = Long.valueOf(splitStr[1])/count;
                    long list = personDtoList.stream().filter(v -> v.getName().equals(name)).count();
                    if(list == 0L) {
                        PersonDto personDto = new PersonDto();
                        personDto.setName(splitStr[i]);
                        personDto.setAmountSpent(amount);
                        personDtoList.add(personDto);
                        if(splitStr[i].equals(splitStr[0])) {
                            personDto.setAmountPaid(Long.valueOf(splitStr[1]));
                        }
                    } else {
                        personDtoList.stream().filter(t -> t.getName().equals(name)).forEach(str -> {
                            long sum = str.getAmountSpent() + amount;
                            str.setAmountSpent(sum);
                        });
                        personDtoList.stream().filter(t -> t.getName().equals(splitStr[0])).forEach(str -> str.setAmountPaid(Long.valueOf(splitStr[1])));
                    }

                }
            }
            CalculationUseCase calculationUseCase = new CalculationUseCase();
            calculationUseCase.calculateDebtsDetails(personDtoList);
    }

    private static String replaceText(String value) {
        List<String> stringList = Arrays.asList("spent", "for", "and", ",");
        for(String item : stringList){
            value = value.replaceAll(item,"");
        }
        return value;
    }

}
